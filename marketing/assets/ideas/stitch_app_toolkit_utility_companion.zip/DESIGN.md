---
name: Kinetic Horizon
colors:
  surface: '#141317'
  surface-dim: '#141317'
  surface-bright: '#3a383d'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1c1b1f'
  surface-container: '#201f23'
  surface-container-high: '#2b292d'
  surface-container-highest: '#353438'
  on-surface: '#e5e1e7'
  on-surface-variant: '#d8c3ad'
  inverse-surface: '#e5e1e7'
  inverse-on-surface: '#313034'
  outline: '#a08e7a'
  outline-variant: '#534434'
  surface-tint: '#ffb95f'
  primary: '#ffc174'
  on-primary: '#472a00'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#855300'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#e1bfff'
  on-tertiary: '#490080'
  tertiary-container: '#ce9bff'
  on-tertiary-container: '#6400ac'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb7ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6900b3'
  background: '#141317'
  on-background: '#e5e1e7'
  surface-variant: '#353438'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 57px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.25px
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 45px
    fontWeight: '700'
    lineHeight: 52px
  display-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.15px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.1px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.4px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system adapts Material Design 3 Expressive for advanced utility workflows, sensor dashboards, and personal tracking. Built specifically around Android 15/16 interface principles, it rejects rigid, sterile utility conventions in favor of a warm, tactile, and responsive environment. The interface combines bento-card structures with dynamic geometric badges and tonal layering to make analytical data visually intuitive.

Key characteristics:
- **Tonal Tactility:** Spatial depth is achieved strictly through chromatic and luminance contrast across container tiers, omitting structural divider lines and harsh borders.
- **Instrument Precision:** High legibility of numeric and parametric information using clean variable geometry.
- **Expressive Morphism:** Fluid transitions between full-radius pills, bento surfaces, and asymmetric polygon badges that celebrate interaction milestones.

## Colors
The color system relies on functional chromatic domains layered over an OLED-tuned, tiered dark foundation. Surfaces avoid pitch black (`#000000`) in favor of deep neutral-tinted containers that provide continuous depth.

### Functional Domains
- **Math & Numeric Precision:** Warm Amber/Gold (`#f59e0b` / `#fbbf24`) drives calculation displays, financial tally sheets, and numeric inputs.
- **Sensors, Hardware & Compass:** Teal/Mint (`#14b8a6` / `#2dd4bf`) governs environmental readouts, gyroscopes, connectivity states, and coordinate overlays.
- **Physical Metrics & Measurement:** Vibrant Orange (`#f97316` / `#fb923c`) indicates real-time dimensioning, unit conversions, and spatial tools.
- **System Controls & Automation:** Violet/Magenta (`#a855f7` / `#c084fc`) handles triggers, global settings, automation flows, and state commutations.
- **Wellbeing & Rhythms:** Deep Amber/Honey (`#d97706` / `#fde68a`) marks calm duration displays, hydration, sleep cycles, and daily rituals.

### Surface Tonal Hierarchy (Dark Mode Target)
- **Surface Dim:** `#111315` — The deep foundation layer for background canvasses.
- **Surface (Base):** `#181a1d` — Root frame space for views and scaffold structures.
- **Surface Container Low:** `#1d2024` — Recessed areas, structural groupings, and background panels.
- **Surface Container:** `#22262a` — Default baseline for standard interactive utility cards.
- **Surface Container High:** `#2a2e34` — Active bento widgets, elevated cards, and highlighted controls.
- **Surface Container Highest:** `#33373e` — Transient overlays, pressed states, search bars, and floating controls.

Text and iconography contrast against these layers using `on-surface` (`#e2e2e6`), `on-surface-variant` (`#c4c6cf`), and soft utility scrims without using opaque borders.

## Typography
The typography balances structural clarity with geometric character. **Plus Jakarta Sans** provides open counters and clean curves for high-density app UI, headlines, and general body copy. **Space Grotesk** is reserved strictly for labels, sensor tags, metadata readouts, coordinates, and numeric badges to deliver a technical, instrument-grade feel.

Implementation rules:
- Numeric metrics and primary digital readouts use tabular numbers (`tnum`) to eliminate layout jitter during high-frequency sensor updates.
- Display sizes leverage tighter negative tracking for compact titles on edge-to-edge mobile screens.
- Labels above 12px maintain slight positive letter tracking to preserve scanning legibility inside colored badges and tonal chips.

## Layout & Spacing
The layout model employs a fluid, asymmetric bento grid that scales from single-column handheld screens to multi-pane split-screen configurations on foldable and tablet devices.

- **Mobile (<600dp):** Single column, 4-column sub-grid for mini metric tiles; canvas margins set to `1rem` (`16px`) with `1rem` column gutters. Components hug the edge-to-edge system insets with dynamic bottom padding to clear gesture bars.
- **Foldables & Tablets (600dp–840dp):** 8-column layout with split utility panels (e.g., live sensor feeds paired with logs); canvas margins set to `1.5rem` (`24px`).
- **Desktop & Expanded (840dp+):** 12-column layout; persistent navigation rail replacing bottom navigation; margins expand to `2.5rem` (`40px`).

Every layout module operates on a strict 4dp/8dp spatial grid. Inner card content uses standard padding of `1.5rem` (`space-lg`), while small sensor tiles and quick-toggle clusters use `1rem` (`space-md`).

## Elevation & Depth
Elevation is conveyed through tonal surface tiers and chromatic luminance, avoiding harsh outlines or heavy dropped shadows.

- **Level 0 (Flat Foundation):** Base view canvases (`surfaceDim` at `#111315`). Zero shadow.
- **Level 1 (Recessed Containers):** Groupings and background list tracts (`surfaceContainerLow` at `#1d2024`). Depth is established through value contrast.
- **Level 2 (Interactive Modules):** Bento utility tiles and tool cards (`surfaceContainer` at `#22262a`). On resting states, these have no dropped shadow; elevation is communicated entirely through tonal contrast.
- **Level 3 (Raised Contexts & Active Nodes):** Floating tool widgets, active sensors, and selected states (`surfaceContainerHigh` at `#2a2e34`). Highlighted elements use a colored ambient back-glow: an extra-diffused 24px blur with 12% opacity tinted with the domain's accent color (e.g., Amber, Mint, Orange).
- **Level 4 (Floating Sheets & Navigation Bars):** Docked bottom bars, modal sheets, and transient dialogs (`surfaceContainerHighest` at `#33373e`). Soft drop: `0px 12px 32px rgba(0, 0, 0, 0.45)`.
- **Dividers & Borders:** Outlines are replaced with `8dp` or `12dp` negative space channels, or subtle tonal transitions between `surfaceContainer` and `surfaceContainerHigh`.

## Shapes
The shape language follows Material Design 3 Expressive's rounded, non-traditional geometric style:

- **Bento & Major Tiles:** Standardized to an expressive `28dp` corner radius. Grouped bento items form cohesive rhythmic compositions.
- **Interactive Controls & Tonal Chips:** Full pill geometry (`9999px` / `50%` radius) ensures immediate target recognition and thumb comfort.
- **Expressive Polygon Badges (56dp Fixed Frame):** Specialized geometric cutouts applied to status indicators, dynamic sensor anchors, and category badges. Badges use smooth Bezier-rounded corners:
  - *Flower (12-lobe):* Daily targets, wellbeing achievements, balance metrics.
  - *Cookie (9-sided scalloped):* Math tool shortcuts, multi-register calculation nodes.
  - *Soft Burst (8-pointed smoothed star):* Urgent alerts, live active sensors, trigger events.
  - *Gem (Angled octagonal pill):* Precision calibrations, level indicators, unit shifts.
  - *Pill:* System status switches, toggle pills.
  - *Arch (Rounded-top tombstone):* Compass headings, vertical measurement feeds.
  - *Clover (4-petal rounded square):* Automation connections, tool grouping bundles.

## Components

### Buttons
- **Primary Expressive Button:** Full pill shape (`height: 56px`), background filled with domain accent (e.g., `#f59e0b`), content rendered in `#181a1d` bold text. Zero border.
- **Tonal Button:** Full pill shape (`height: 48px`), background styled in `surfaceContainerHighest` with accented icon/text tints. Hover and pressed states lighten the background container tone by 8%.

### Borderless Tonal Assist Chips
- **Geometry:** Full pill shape (`height: 36px`, padding horizontal `16px`).
- **Surface:** Borderless. Filled with `surfaceContainerHigh` (`#2a2e34`).
- **Typography:** Space Grotesk `label-md`.
- **States:** Active/Selected switches the fill to a 20% alpha wash of the category color with solid accent text, avoiding outer boundary strokes.

### Bento Tool Cards
- **Geometry:** Expressive `28dp` corner radius.
- **Surface:** `surfaceContainer` (`#22262a`) resting; shifts smoothly to `surfaceContainerHigh` (`#2a2e34`) on press.
- **Padding:** `1.5rem` (`24px`).
- **Arrangement:** Contains an expressive 56dp badge in the top corner, large numeric reading in Plus Jakarta Sans display typography, and a Space Grotesk label anchored to the bottom.

### Expressive Polygon Badges
- **Size:** `56dp × 56dp` bounding footprint.
- **Material:** Filled with contextual domain accents (Warm Amber, Mint, Orange, Violet) rendered at either 100% saturation for active events or 15% tonal fill with solid foreground icon.

### Form Inputs & Numeric Scaffolding
- **Geometry:** `20dp` soft-curved containers; `height: 60px`.
- **Color:** Completely borderless `surfaceContainerLow` backdrop. On focus, smoothly transitions to `surfaceContainerHighest` accompanied by a 2dp bottom indicator line tinted with the domain accent.

### Checkboxes, Radios, & Switches
- **Switches:** M3 Expressive track (`width: 52px`, `height: 32px`, pill) filled with `surfaceContainerHighest`. Active thumb expands into a rounded rectangular pill (`28dp × 28dp`) in domain color.
- **Checkboxes:** `24dp × 24dp` with `8dp` rounded corners. Tonal fill when checked; no unselected border line—unselected states rely on `surfaceContainerHighest` fill against the container base.

### Lists
- **Structure:** Non-divided card lists. Rows sit on `surfaceContainer` as unified capsules, separated by an `8dp` layout gap rather than visual hairline rules.

### Expressive Pill Bottom Navigation
- **Architecture:** Floating dock centered horizontally above the gesture bar; corner radius `32dp`.
- **Surface:** `surfaceContainerHighest` with back-panel blur.
- **Active Indicator:** Smooth pill-shaped indicator (`height: 40px`, `width: 64px`) filled with primary domain accent, with icons morphing into active filled states.